-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: localhost:3307
-- Tiempo de generación: 11-04-2025 a las 00:22:07
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `tienda_ropa`
--

DELIMITER $$
--
-- Procedimientos
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `actualizar_categorias_clientes` ()   BEGIN
    DECLARE cliente_id INT;
    DECLARE total_unidades INT;
    DECLARE done INT DEFAULT FALSE;

    -- Cursor para recorrer clientes
    DECLARE cur CURSOR FOR
        SELECT c.id_cliente, COALESCE(SUM(dp.cantidad), 0) AS total
        FROM clientes c
        LEFT JOIN pedidos p ON c.id_cliente = p.id_cliente AND MONTH(p.fecha) = MONTH(CURDATE()) AND YEAR(p.fecha) = YEAR(CURDATE())
        LEFT JOIN detalles_pedido dp ON p.id_pedido = dp.id_pedido
        GROUP BY c.id_cliente;

    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN cur;

    read_loop: LOOP
        FETCH cur INTO cliente_id, total_unidades;
        IF done THEN
            LEAVE read_loop;
        END IF;

        -- Lógica de actualización de categoría
        IF total_unidades <= 10 THEN
            UPDATE clientes SET categoria_id = 1 WHERE id_cliente = cliente_id;
        ELSEIF total_unidades > 10 AND total_unidades <= 30 THEN
            UPDATE clientes SET categoria_id = 2 WHERE id_cliente = cliente_id;
        ELSE
            UPDATE clientes SET categoria_id = 3 WHERE id_cliente = cliente_id;
        END IF;

    END LOOP;

    CLOSE cur;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `categorias_clientes`
--

CREATE TABLE `categorias_clientes` (
  `id_categoria` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `descuento` decimal(4,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `categorias_clientes`
--

INSERT INTO `categorias_clientes` (`id_categoria`, `nombre`, `descuento`) VALUES
(1, 'Básico', 0.00),
(2, 'Frecuente', 0.05),
(3, 'VIP', 0.10);

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `clasificacion_clientes`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `clasificacion_clientes` (
`id_cliente` int(11)
,`nombre` varchar(100)
,`categoria_asignada` varchar(9)
,`mes` int(2)
,`año` int(4)
);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `clientes`
--

CREATE TABLE `clientes` (
  `id_cliente` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `correo` varchar(100) DEFAULT NULL,
  `categoria_id` int(11) DEFAULT NULL,
  `fecha_registro` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `clientes`
--

INSERT INTO `clientes` (`id_cliente`, `nombre`, `correo`, `categoria_id`, `fecha_registro`) VALUES
(1, 'Keyvert Anderson', 'keyvert@losso.com', 3, '2025-04-10 20:22:38'),
(2, 'Luisa Fernanda', 'luisa@losso.com', 2, '2025-04-10 20:22:38'),
(3, 'Johan Salazar', 'johan@losso.com', 1, '2025-04-10 20:22:38'),
(4, 'Distribuciones LOSSO', 'contacto@losso.com', 3, '2025-04-10 21:34:04');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `detalles_pedido`
--

CREATE TABLE `detalles_pedido` (
  `id_detalle` int(11) NOT NULL,
  `id_pedido` int(11) DEFAULT NULL,
  `id_producto` int(11) DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  `precio_unitario` decimal(10,2) DEFAULT NULL,
  `subtotal` decimal(10,2) DEFAULT NULL,
  `tiempo_entrega_estimada` int(11) DEFAULT NULL COMMENT 'Tiempo en horas estimado para entrega del producto'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `detalles_pedido`
--

INSERT INTO `detalles_pedido` (`id_detalle`, `id_pedido`, `id_producto`, `cantidad`, `precio_unitario`, `subtotal`, `tiempo_entrega_estimada`) VALUES
(1, 1, 1, 2, 42000.00, 84000.00, NULL),
(2, 1, 4, 1, 50000.00, 50000.00, NULL),
(3, 2, 5, 1, 150000.00, 150000.00, NULL);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `entregas`
--

CREATE TABLE `entregas` (
  `id_entrega` int(11) NOT NULL,
  `id_detalle` int(11) DEFAULT NULL,
  `fecha_entrega_real` datetime DEFAULT NULL,
  `observaciones` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `mayoristas`
--

CREATE TABLE `mayoristas` (
  `id_mayorista` int(11) NOT NULL,
  `id_cliente` int(11) DEFAULT NULL,
  `nombre_empresa` varchar(100) DEFAULT NULL,
  `nit` varchar(20) DEFAULT NULL,
  `contacto_responsable` varchar(100) DEFAULT NULL,
  `telefono_responsable` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `mayoristas`
--

INSERT INTO `mayoristas` (`id_mayorista`, `id_cliente`, `nombre_empresa`, `nit`, `contacto_responsable`, `telefono_responsable`) VALUES
(1, 4, 'LOSO Distribuciones S.A.S.', '901234567-8', 'María Torres', '3123456789');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `metodos_pago`
--

CREATE TABLE `metodos_pago` (
  `id_pago` int(11) NOT NULL,
  `nombre` varchar(50) DEFAULT NULL,
  `descripcion` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `metodos_pago`
--

INSERT INTO `metodos_pago` (`id_pago`, `nombre`, `descripcion`) VALUES
(1, 'Efectivo', 'Pago en efectivo'),
(2, 'Transferencia', 'Transferencia a cuenta bancaria'),
(3, 'Tarjeta', 'Débito o crédito');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pagos`
--

CREATE TABLE `pagos` (
  `id_pago` int(11) NOT NULL,
  `id_pedido` int(11) DEFAULT NULL,
  `id_metodo` int(11) DEFAULT NULL,
  `monto` decimal(10,2) DEFAULT NULL,
  `fecha_pago` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pagos`
--

INSERT INTO `pagos` (`id_pago`, `id_pedido`, `id_metodo`, `monto`, `fecha_pago`) VALUES
(1, 1, 2, 134000.00, '2025-04-10 20:22:38'),
(2, 2, 3, 150000.00, '2025-04-10 20:22:38');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `pedidos`
--

CREATE TABLE `pedidos` (
  `id_pedido` int(11) NOT NULL,
  `id_cliente` int(11) DEFAULT NULL,
  `fecha` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `total` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `pedidos`
--

INSERT INTO `pedidos` (`id_pedido`, `id_cliente`, `fecha`, `total`) VALUES
(1, 1, '2025-04-10 20:22:38', 134000.00),
(2, 2, '2025-04-10 20:22:38', 150000.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `productos`
--

CREATE TABLE `productos` (
  `id_producto` int(11) NOT NULL,
  `nombre` varchar(100) DEFAULT NULL,
  `valor_unitario` decimal(10,2) DEFAULT NULL,
  `cantidad_stock` int(11) DEFAULT NULL,
  `fecha_vencimiento` date DEFAULT NULL,
  `estado` enum('Disponible','Por Agotar','Vencido','No Disponible') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `productos`
--

INSERT INTO `productos` (`id_producto`, `nombre`, `valor_unitario`, `cantidad_stock`, `fecha_vencimiento`, `estado`) VALUES
(1, 'Camiseta Oversize LOSSO Negra', 42000.00, 30, '2026-12-31', 'Disponible'),
(2, 'Sudadera Clásica LOSSO Gris', 89000.00, 15, '2026-12-31', 'Disponible'),
(3, 'Buzo Capota LOSSO Azul Marino', 95000.00, 10, '2025-11-30', 'Por Agotar'),
(4, 'Bermuda Deportiva LOSSO Negra', 55000.00, 25, '2026-05-20', 'Disponible'),
(5, 'Conjunto Jogger + Hoodie LOSSO Blanco', 150000.00, 5, '2025-10-01', 'Disponible');

-- --------------------------------------------------------

--
-- Estructura Stand-in para la vista `vista_productos_cliente`
-- (Véase abajo para la vista actual)
--
CREATE TABLE `vista_productos_cliente` (
`nombre` varchar(100)
,`valor_unitario` decimal(10,2)
,`cantidad_stock` int(11)
,`estado` varchar(10)
);

-- --------------------------------------------------------

--
-- Estructura para la vista `clasificacion_clientes`
--
DROP TABLE IF EXISTS `clasificacion_clientes`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `clasificacion_clientes`  AS SELECT `c`.`id_cliente` AS `id_cliente`, `c`.`nombre` AS `nombre`, CASE WHEN sum(`dp`.`cantidad`) <= 10 THEN 'Básico' WHEN sum(`dp`.`cantidad`) > 10 AND sum(`dp`.`cantidad`) <= 30 THEN 'Frecuente' WHEN sum(`dp`.`cantidad`) > 30 THEN 'VIP' END AS `categoria_asignada`, month(`p`.`fecha`) AS `mes`, year(`p`.`fecha`) AS `año` FROM ((`clientes` `c` join `pedidos` `p` on(`c`.`id_cliente` = `p`.`id_cliente`)) join `detalles_pedido` `dp` on(`p`.`id_pedido` = `dp`.`id_pedido`)) GROUP BY `c`.`id_cliente`, month(`p`.`fecha`), year(`p`.`fecha`) ;

-- --------------------------------------------------------

--
-- Estructura para la vista `vista_productos_cliente`
--
DROP TABLE IF EXISTS `vista_productos_cliente`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `vista_productos_cliente`  AS SELECT `productos`.`nombre` AS `nombre`, `productos`.`valor_unitario` AS `valor_unitario`, `productos`.`cantidad_stock` AS `cantidad_stock`, CASE WHEN `productos`.`cantidad_stock` = 0 THEN 'Agotado' WHEN `productos`.`cantidad_stock` <= 5 THEN 'Bajo stock' ELSE 'Disponible' END AS `estado` FROM `productos` ;

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `categorias_clientes`
--
ALTER TABLE `categorias_clientes`
  ADD PRIMARY KEY (`id_categoria`);

--
-- Indices de la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id_cliente`),
  ADD UNIQUE KEY `correo` (`correo`),
  ADD KEY `categoria_id` (`categoria_id`);

--
-- Indices de la tabla `detalles_pedido`
--
ALTER TABLE `detalles_pedido`
  ADD PRIMARY KEY (`id_detalle`),
  ADD KEY `id_pedido` (`id_pedido`),
  ADD KEY `id_producto` (`id_producto`);

--
-- Indices de la tabla `entregas`
--
ALTER TABLE `entregas`
  ADD PRIMARY KEY (`id_entrega`),
  ADD KEY `id_detalle` (`id_detalle`);

--
-- Indices de la tabla `mayoristas`
--
ALTER TABLE `mayoristas`
  ADD PRIMARY KEY (`id_mayorista`),
  ADD KEY `id_cliente` (`id_cliente`);

--
-- Indices de la tabla `metodos_pago`
--
ALTER TABLE `metodos_pago`
  ADD PRIMARY KEY (`id_pago`);

--
-- Indices de la tabla `pagos`
--
ALTER TABLE `pagos`
  ADD PRIMARY KEY (`id_pago`),
  ADD KEY `id_pedido` (`id_pedido`),
  ADD KEY `id_metodo` (`id_metodo`);

--
-- Indices de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id_pedido`),
  ADD KEY `id_cliente` (`id_cliente`);

--
-- Indices de la tabla `productos`
--
ALTER TABLE `productos`
  ADD PRIMARY KEY (`id_producto`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id_cliente` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `detalles_pedido`
--
ALTER TABLE `detalles_pedido`
  MODIFY `id_detalle` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `entregas`
--
ALTER TABLE `entregas`
  MODIFY `id_entrega` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `mayoristas`
--
ALTER TABLE `mayoristas`
  MODIFY `id_mayorista` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id_pedido` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `productos`
--
ALTER TABLE `productos`
  MODIFY `id_producto` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `clientes`
--
ALTER TABLE `clientes`
  ADD CONSTRAINT `clientes_ibfk_1` FOREIGN KEY (`categoria_id`) REFERENCES `categorias_clientes` (`id_categoria`);

--
-- Filtros para la tabla `detalles_pedido`
--
ALTER TABLE `detalles_pedido`
  ADD CONSTRAINT `detalles_pedido_ibfk_1` FOREIGN KEY (`id_pedido`) REFERENCES `pedidos` (`id_pedido`),
  ADD CONSTRAINT `detalles_pedido_ibfk_2` FOREIGN KEY (`id_producto`) REFERENCES `productos` (`id_producto`);

--
-- Filtros para la tabla `entregas`
--
ALTER TABLE `entregas`
  ADD CONSTRAINT `entregas_ibfk_1` FOREIGN KEY (`id_detalle`) REFERENCES `detalles_pedido` (`id_detalle`);

--
-- Filtros para la tabla `mayoristas`
--
ALTER TABLE `mayoristas`
  ADD CONSTRAINT `mayoristas_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`);

--
-- Filtros para la tabla `pagos`
--
ALTER TABLE `pagos`
  ADD CONSTRAINT `pagos_ibfk_1` FOREIGN KEY (`id_pedido`) REFERENCES `pedidos` (`id_pedido`),
  ADD CONSTRAINT `pagos_ibfk_2` FOREIGN KEY (`id_metodo`) REFERENCES `metodos_pago` (`id_pago`);

--
-- Filtros para la tabla `pedidos`
--
ALTER TABLE `pedidos`
  ADD CONSTRAINT `pedidos_ibfk_1` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id_cliente`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
